self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "41e1daf55b4c26793f34",
    "url": "css/app.05b0bb75.css"
  },
  {
    "revision": "6078a6e9c0a8b2035d2d",
    "url": "css/chunk-vendors.40f7e81c.css"
  },
  {
    "revision": "e8d7ca35feac4047a8be666590238ba8",
    "url": "index.html"
  },
  {
    "revision": "41e1daf55b4c26793f34",
    "url": "js/app-legacy.05d08484.js"
  },
  {
    "revision": "6078a6e9c0a8b2035d2d",
    "url": "js/chunk-vendors-legacy.22c5fd4e.js"
  },
  {
    "revision": "2eea4dd25fbda25211ac1b0b9686d347",
    "url": "manifest.json"
  }
]);